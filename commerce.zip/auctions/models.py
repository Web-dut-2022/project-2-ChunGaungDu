from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass

class Bid(models.Model):
    bid=models.IntegerField()
    bUser_id=models.ForeignKey(User,on_delete=models.CASCADE)
    bState=models.BooleanField(default=0)

class Auction(models.Model):
    aNo=models.AutoField(primary_key=True)
    aUser_id=models.ForeignKey(User,on_delete=models.CASCADE)
    aTitle=models.CharField(max_length=20)
    aType=models.CharField(max_length=5)
    aDes=models.CharField(max_length=50)
    aImageUrl=models.URLField()
    aState=models.BooleanField(default=0)    
    aBid_id=models.OneToOneField(Bid,unique=True,on_delete=models.PROTECT)


class Comments(models.Model):
    cAuction_id=models.ForeignKey(Auction,on_delete=models.CASCADE)
    cContent=models.TextField(max_length=300)
    cUser_id=models.ForeignKey(User,on_delete=models.CASCADE)
    cDate=models.DateField()


class WatchList(models.Model):
    wUser_id=models.ForeignKey(User,on_delete=models.CASCADE)
    wAuction_id=models.ForeignKey(Auction,on_delete=models.CASCADE)