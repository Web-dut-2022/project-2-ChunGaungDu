from pydoc import describe
from webbrowser import get
from xml.etree.ElementTree import Comment
from django.contrib.auth import authenticate, login, logout
from django.contrib import auth
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.contrib import messages
from django.utils import timezone
from django.contrib.auth.decorators import login_required
import random

import auctions
from .models import Auction, Comments, User, Bid , WatchList


def index(request):
    auctions= Auction.objects.filter(aState=0).all()
    return render(request, "auctions/index.html",{"auctions":auctions})


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            auth_obj = auth.authenticate(request, username=username, password=password)
            if auth_obj:
            # 需要auth验证cookie
                auth.login(request, auth_obj)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")

@login_required
def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")

@login_required
def AddNew(request):
    if request.method == "POST":
        user=request.user
        title=request.POST['title']
        type=request.POST['type']
        description=request.POST['description']
        b=request.POST['bid']
        bid=Bid(bid=b,bUser_id=user)
        bid.save()
        image=request.POST['image']
        auction=Auction(aUser_id=user,aTitle=title,aType=type,aDes=description,aBid_id=bid,aImageUrl=image)
        auction.save()
        return index(request)
    else:
        return render(request, "auctions/new.html")

def ShowListing(request):
    no=request.GET['NO']
    auction=Auction.objects.get(aNo=no)
    comments=Comments.objects.filter(cAuction_id=auction).all()
    owner=auction.aUser_id
    bid=auction.aBid_id
    return render(request,"auctions/listingPage.html",{"auction":auction,"comments":comments,"owner":owner,"Bid":bid})

def Randomau(request):
    auctions=Auction.objects.filter(aState=0).all()
    num=random.randint(0,len(auctions)-1)
    return render(request, "auctions/index.html",{"auction":auctions[num]})

@login_required
def AddtoWatchList(request):
    no=request.GET['NO']
    auction=Auction.objects.get(aNo=no)
    user=request.user
    watch=WatchList(wUser_id=user,wAuction_id=auction)
    watch.save()
    messages.success(request, '成功加入WatchList')
    return render(request, 'auctions/listingPage.html', {})

@login_required
def AddComment(request):
    content=request.GET['comment']
    no=request.GET['NO']
    auction=Auction.objects.get(aNo=no)
    user=request.user
    date=timezone.localdate()
    comment=Comments(cAuction_id=auction,cContent=content,cUser_id=user,cDate=date)
    comment.save()
    messages.success(request, '评论成功')
    return render(request, 'auctions/listingPage.html', {})

@login_required
def CloseAuction(request):
    no=request.GET['NO']
    auction=Auction.objects.get(aNo=no)
    Auction.objects.filter(aNo=no).update(aState=1)
    bid=auction.aBid_id
    bid.bState=1
    bid.save()
    messages.success(request, '该拍卖已关闭')
    return render(request, 'auctions/listingPage.html', {})

@login_required
def SaveBid(request):
    no=request.GET['NO']
    bid=request.GET['bid']
    user=request.user
    auction=Auction.objects.get(aNo=no)
    oldbid=auction.aBid_id
    oldbid.bUser_id=user
    oldbid.bid=bid
    oldbid.save()
    messages.success(request, '拍价已上传')
    return render(request, 'auctions/listingPage.html', {})

@login_required
def ShowWatch(request):
    user=request.user
    auctions=WatchList.objects.filter(wUser_id=user).all()
    return render(request,'auctions/watchlist.html',{"auctions":auctions})

def Categories(request):
    return render(request,'auctions/categories.html')

def ChooseCategory(request):
    type=request.GET['type']
    list=Auction.objects.filter(aType=type).all()
    return render(request,"auctions/index.html",{"auctions":list})
